module.exports = {
    port: process.env.PORT || 4000,
    dbConnectionString: process.env.DB_CONNECTION_STRING,
    // Add any other configuration options you need
  };